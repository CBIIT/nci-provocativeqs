<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en"
      lang="en">

  
    
    
    
    
    

  

  <head>
    <meta http-equiv="Content-Type"
          content="text/html;charset=utf-8" />

    <title>

        
        Provocative Questions
    </title>



<div style="position:absolute;">
<a href="#skip">
<img src="http://provocativequestions.nci.nih.gov/skipnav.gif"
     border="0" height="1" width="1" alt="Skip Navigation"
     title="Skip Navigation" />
</a>
</div>

    
      
        <base href="http://provocativequestions.nci.nih.gov/" />
      
    

    <meta name="generator" content="Plone - http://plone.org" />


    <!-- Plone ECMAScripts -->
    
      
        
            
                <script type="text/javascript"
                        src="http://provocativequestions.nci.nih.gov/portal_javascripts/GreenTheme/ploneScripts5880.js">
                </script>
                
            
        
    
    

    
	
          
        
            
                
                    
                    
                        <style type="text/css"
    media="screen"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/base.css); --></style>
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css"
    media="screen"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/public.css); --></style>
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css"
    media="screen"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/columns.css); --></style>
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css"
    media="screen"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/authoring.css); --></style>
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css"
    media="screen"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/portlets.css); --></style>
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css"
    media="projection"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/presentation.css); --></style>
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css" media="print"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/print.css); --></style>
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css"
    media="handheld"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/mobile.css); --></style>
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css"
    media="screen"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/deprecated.css); --></style>
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css"
    media="screen"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/generated.css); --></style>
                    
                    
                
            
            
                
                    <link rel="alternate stylesheet"
                          type="text/css" media="screen"
                          href="http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/textSmall.css"
                          title="Small Text" />
                    
                    
                
            
            
                
                    <link rel="alternate stylesheet"
                          type="text/css" media="screen"
                          href="http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/textLarge.css"
                          title="Large Text" />
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css"
    media="screen"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/greentheme.css); --></style>
                    
                    
                
            
            
                
                    
                    
                        <style type="text/css" media="all"><!-- @import url(http://provocativequestions.nci.nih.gov/portal_css/GreenTheme/ploneCustom.css); --></style>
                    
                    
                
            
        
    
        
        
    

    <!-- Internet Explorer CSS Fixes -->
    <!--[if IE]>
        <style type="text/css" media="all">@import url(http://provocativequestions.nci.nih.gov/IEFixes.css);</style>
    <![endif]-->

    <link rel="shortcut icon" type="image/x-icon"
          href="http://provocativequestions.nci.nih.gov/favicon.ico" />

    <link rel="home"
          href="http://provocativequestions.nci.nih.gov"
          title="Front page" />
    <link rel="search"
          href="http://provocativequestions.nci.nih.gov/search_form"
          title="Search this site" />
    <link rel="author"
          href="http://provocativequestions.nci.nih.gov/author/"
          title="Author information" />
    <link rel="contents"
          href="http://provocativequestions.nci.nih.gov/sitemap"
          title="Site Map" />

    

    

    

    

    <!-- Disable IE6 image toolbar -->
    <meta http-equiv="imagetoolbar" content="no" />
    
    
      
      
    

    
      
      
    

    
      
      
    

    
      
      
    
<!-- begin GA -->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-19781778-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!-- end GA -->


  </head>

  <body dir="ltr">

    <div id="visual-portal-wrapper">
      <div id="portal-top" class="subpagesLogoBg">
<ul class="minibanner">
  <li class="nci"><a href="http://www.cancer.gov"><img
    src="http://provocativequestions.nci.nih.gov/minibanner_nci.gif"
    width="245" height="34" alt="National Cancer Institute" /></a></li>
  <li class="nih"><a href="http://www.nih.gov"><img
    src="http://provocativequestions.nci.nih.gov/minibanner_nih.gif"
    width="165" height="34" alt="National Cancer Institute" /></a></li>
  <li class="cancergov"><a href="http://www.cancer.gov"><img
    src="http://provocativequestions.nci.nih.gov/minibanner_cancer_gov.gif"
    width="85" height="34" alt="National Cancer Institute" /></a></li>
</ul>
     
        <div id="portal-header">
					<div id="portal-logo">
          <a href="http://provocativequestions.nci.nih.gov"
             title="Provocative Questions: Identifying Perplexing Problems  to Drive Progress Against Cancer"
             alt="Provocative Questions: Identifying Perplexing Problems  to Drive Progress Against Cancer"
             accesskey="1">Provocative Questions</a>
        </div>
	         
          <p class="hiddenStructure">
            <a accesskey="2"
               href="http://provocativequestions.nci.nih.gov/restserver.php#documentContent">Skip to content.</a> |

            <a accesskey="6"
               href="http://provocativequestions.nci.nih.gov/restserver.php#portlet-navigation-tree">Skip to navigation</a>
          </p>

             


             <div id="portal-skinswitcher">
  
</div>
          </div>

					
		<h5 class="hiddenStructure">Sections</h5>
		<div id="portal-globalnav">
			<ul id="portal-tabs-only"
       class="navTreeLevel0 visualNoMarker">
	
				<li class="navTreeItem navTreeCurrentItem visualNoMarker">
					<div class="contenttype-plone-site">
						<span class="visualIconPadding">Home</span>
					</div>
				</li>
                                <!-- Not sure what the line below is used for but commenting it out fixes the issue of excluded nav items from showing up in the nav if they are current nav items -->
				<!--<metal:main use-macro="here/global_sections/macros/top_tabs" />-->
			</ul>
      <ul id="portal-full-sitemap"
          class="navTreeLevel0 visualNoMarker">
        <li class="navTreeItem visualNoMarker">
          <div class="contenttype-plone-site">
              <a href="http://provocativequestions.nci.nih.gov"
                 class="navTreeCurrentItem visualIconPadding"
                 title="">Home</a>
          </div>
        </li>
        



<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-suggestionform rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/rfa"
          class="state-visible visualIconPadding" title="">Current RFAs and PQs</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-folder rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/community-dialog"
          class="state-published visualIconPadding" title="">Community Dialog</a>
        
    </div>
    <ul class="navTree navTreeLevel2">
        

<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-folder rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/community-dialog/us-workshops"
          class="state-visible visualIconPadding" title="">US Workshops</a>
        
    </div>
    <ul class="navTree navTreeLevel3">
        

<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-suggestionform rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/community-dialog/us-workshops/provocative-questions"
          class="state-visible visualIconPadding" title="">Questions from Workshops</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-suggestionform rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/community-dialog/us-workshops/Questions"
          class="state-published visualIconPadding" title="">Questions Submitted Online</a>
        
    </div>
    
    
</li>


    </ul>
    
</li>


    </ul>
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-folder rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings"
          class="state-published visualIconPadding"
          title="Meetings &amp; Outcomes">Workshops</a>
        
    </div>
    <ul class="navTree navTreeLevel2">
        

<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-document rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/10-9-2010-pq-summary"
          class="state-visible visualIconPadding" title="">10-9-2010 PQ Summary</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-file rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/Oct-9-2010-PQ-Roster.pdf/view"
          class="state-visible visualIconPadding" title="">10-9-2010 PQ Roster</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-document rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/2-2-2011-pq-summary"
          class="state-visible visualIconPadding" title="">2-2-2011 PQ Summary</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-file rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/PQ-2-2-2011-Roster.pdf/view"
          class="state-visible visualIconPadding" title="">2-2-2011 PQ Roster</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-document rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/2-4-2011-pq-summary"
          class="state-visible visualIconPadding" title="">2-4-2011 PQ Summary</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-file rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/PQ-2-4-2011-Roster.pdf/view"
          class="state-visible visualIconPadding" title="">2-4-2011 PQ Roster</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-file rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/PQ-2-10-2011-Roster.pdf/view"
          class="state-visible visualIconPadding" title="">2-10-2011 PQ Roster</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-document rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/7-11-2011-pq-summary"
          class="state-visible visualIconPadding" title="">7-11-2011 PQ Summary</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-file rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/7-11-2011%20PQ%20Roster.pdf/view"
          class="state-visible visualIconPadding" title="">7-11-2011 PQ Roster</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-document rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/7-21-2011-pq-summary"
          class="state-visible visualIconPadding" title="">7-21-2011 PQ Summary</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-file rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/7-21-2011%20PQ%20Roster.pdf/view"
          class="state-visible visualIconPadding" title="">7-21-2011 PQ Roster</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-document rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/8-2-2011-pq-summary"
          class="state-visible visualIconPadding" title="">8-2-2011 PQ Summary</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-file rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/8-2-2011%20PQ%20Roster.pdf/view"
          class="state-visible visualIconPadding" title="">8-2-2011 PQ Roster</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-document rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/8-4-2011-pq-summary"
          class="state-visible visualIconPadding" title="">8-4-2011 PQ Summary</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-file rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/meetings/8-4-2011%20PQ%20Roster.pdf/view"
          class="state-visible visualIconPadding" title="">8-4-2011 PQ Roster</a>
        
    </div>
    
    
</li>


    </ul>
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-folder rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/archived-rfas-and-pqs"
          class="state-visible visualIconPadding" title="">Archived RFAs and PQs</a>
        
    </div>
    <ul class="navTree navTreeLevel2">
        

<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-suggestionform rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/archived-rfas-and-pqs/rfa-archive-2011"
          class="state-visible visualIconPadding" title="">2011 Archived RFAs and PQs</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-suggestionform rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/archived-rfas-and-pqs/rfa-archive-2012"
          class="state-visible visualIconPadding" title="">2012 Archived RFAs and PQs</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-suggestionform rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/archived-rfas-and-pqs/rfa-archive-2013"
          class="state-visible visualIconPadding" title="">2013 Archived RFAs and PQs</a>
        
    </div>
    
    
</li>


    </ul>
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-folder rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/about"
          class="state-visible visualIconPadding" title="">About PQ</a>
        
    </div>
    
    
</li>


<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-folder rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/indian-pq-workshops"
          class="state-visible visualIconPadding" title="">Indian PQ Workshops</a>
        
    </div>
    <ul class="navTree navTreeLevel2">
        

<li class="navTreeItem visualNoMarker">

    

    <div class="visualIcon contenttype-suggestionform rfaasdasdassa">
        
        

       <a href="http://provocativequestions.nci.nih.gov/indian-pq-workshops/Questions"
          class="state-visible visualIconPadding" title="">Questions Submitted Online for the Indian PQ Workshops</a>
        
    </div>
    
    
</li>


    </ul>
    
</li>



    	</ul>
    </div>

    <script type="text/javascript"
            src="http://provocativequestions.nci.nih.gov/suckerfish.js"></script>
    <script type="text/javascript">
    	suckerfish(sfHover, "LI", "portal-globalnav");
    </script>
	

					


	<div class="breadcrumbs-search">
		<div class="breadcrumbs">


    <a href="http://provocativequestions.nci.nih.gov">Home</a>
    

</div>
	</div>

      </div>

      <div class="visualClear" id="clear-space-before-wrapper-table"><!-- --></div>

      

      <table id="portal-columns">
        <tbody>
          <tr>
            
            
            
            <a name="skip" id="skip"></a>
            
            <td id="portal-column-content">

              
                <div id="content" class="">

                  

                  <div class="documentContent" id="region-content">

                    <a name="documentContent"></a>

                    

    



                    

                    <div>

        <div>

            <h1>Our apologies...</h1>

            <p>
            The item you requested does not exist on this server or cannot be served.
            </p>

            <p>
            Please double check the web address or use the search function on this page to find what you are looking for.
            </p>

            <p>
            If you know you have the correct web address but are encountering an error, please
            contact the <a href="http://provocativequestions.nci.nih.gov/contact-info">Site Administration</a>.
            </p>

            <p>
            Thank you.
            </p>

            <code>
            404 Not Found
            </code>

        </div>

        
</div>

                    
                      
                 
    

                    

                  </div>

                </div>

              
            </td>
            

            
            
            
          </tr>
        </tbody>
      </table>
      

      <div class="visualClear" id="clear-space-before-footer"><!-- --></div>


      <hr class="netscape4" />

      

        
		
        <div id="portal-footer">
            <div class="footerLinks">
                <a href="http://provocativequestions.nci.nih.gov"
                   title="Home">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a
    href="http://provocativequestions.nci.nih.gov/contact_us"
    title="Contact Us">Contact Us</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a
    href="http://provocativequestions.nci.nih.gov/sitemap"
    title="Site Map">Site Map</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.cancer.gov/global/web/policies" title="Policies">Policies</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.cancer.gov/global/web/policies/page3" title="Accessibility">Accessibility</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://cancer.gov/global/viewing-files" target="_blank" title="Viewing Files">Viewing Files</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.cancer.gov/global/web/policies/page6" title="FOIA">FOIA</a><br /><br />
                <a href="http://www.dhhs.gov/">Department of Health and Human Services</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.nih.gov/">National Institutes of Health</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.cancer.gov/">National Cancer Institute</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.usa.gov/">USA.gov</a>
            </div><br /><br />
            NIH...Turning Discovery Into Health
        </div>

<!-- **** NCI Web Analytics **** -->

    <script type="text/javascript" language="javascript" src="http://static.cancer.gov/webanalytics/WA_PQ_pageLoad.js"></script>
 
<!-- **** End NCI Web Analytics **** -->


  


      

    </div>
	
</body>
</html>

