
// Version 2.1
document.write('<script type="text/javascript" src="//static.cancer.gov/webanalytics/WA_PQ_pre.js" ></script>');
document.write('<script type="text/javascript" src="//static.cancer.gov/webanalytics/s_code.js" ></script>');
document.write('<script type="text/javascript" src="//static.cancer.gov/webanalytics/WA_PQ_post.js" ></script>');

// Add the line below just before the end body tag to execute NCI Omniture page-load event:
//<script type="text/javascript" language="javascript" src="//static.cancer.gov/webanalytics/WA_PQ_pageLoad.js"></script>

